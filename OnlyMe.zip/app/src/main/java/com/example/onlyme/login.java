package com.example.onlyme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {
EditText edit_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        edit_password=findViewById(R.id.password);

        edit_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password=edit_password.getText().toString();
                if(password.equals("12345")) {
                    System.out.print("0!");
                }
                else{
                    System.out.print("X!");

            }}
            });
        }
    }