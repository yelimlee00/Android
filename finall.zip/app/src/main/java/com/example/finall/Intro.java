package com.example.finall;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Intro extends AppCompatActivity {
    Button btn1;
    View dialogView;
    EditText pwd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);
        btn1=(Button)findViewById(R.id.btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogView=(View)View.inflate(Intro.this,R.layout.dialog1,null);
                AlertDialog.Builder dlg=new AlertDialog.Builder(Intro.this);
                dlg.setTitle("WELCOME");
                dlg.setMessage("비밀번호입력");
                dlg.setView(dialogView);
                dlg.setPositiveButton("LOGIN", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {


                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(intent);



                    }
                });
                dlg.show();
            }

        });
    }
}