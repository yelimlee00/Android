package com.example.final7;

import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

public class LoginFragment2 extends Fragment {
    EditText tvId;
    EditText tvPwd;
    Button btnLogin;
    SharedPreferences preferences;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_login, container, false);
        tvId = (EditText) view.findViewById(R.id.tvId);
        tvPwd = (EditText) view.findViewById(R.id.tvPwd);
        btnLogin = (Button) view.findViewById(R.id.btnLogin);
        RequestQueue requestQueue2 = Volley.newRequestQueue(getContext());
        String url1 = "http://172.30.1.54:8080/android1/login.jsp";

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url2 = url1 + "?id=" + tvId.getText().toString() +
                        "&pwd=" + tvPwd.getText().toString();
                System.out.println("\n"+url2);
                StringRequest stringRequest = new StringRequest(
                        Request.Method.GET,
                        url2,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    System.out.println("\n\nresponse:  "+response);
                                    String name = response.substring(3);//jobj.getString("name");
                                    //for(int i = 0; i<response.length()-1; i++)
                                    //System.out.println("\ni: "+i+" " + response.trim().charAt(i));
                                    System.out.println("\nname:===========" + response.contains("error"));
                                    if (!response.contains("error")) {
                                        //shared Preference
/*                              preferences = getContext().getSharedPreferences("userInfo", MODE_PRIVATE);
                              SharedPreferences.Editor editor = preferences.edit();
                              editor.putString("name", name);
                              editor.commit();*/
                                        System.out.println("\n\n이름:" + name);
                                        Toast.makeText(getContext(), "이름:" + name, Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(getContext(), "login: " + "error", Toast.LENGTH_SHORT).show();
                                        System.out.println("\n\n" + "error");
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(getContext(), "error: " + error.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                );
                requestQueue2.add(stringRequest);
            }
        });
        return view;
    }
}