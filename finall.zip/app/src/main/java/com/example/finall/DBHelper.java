package com.example.finall;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.security.PublicKey;

class DBHelper extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public DBHelper(@Nullable Context context) {
        super(context, "mydb", null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query_create = "CREATE TABLE upload1(" +
                "fname CHAR(50) PRIMARY KEY ," +
                "location CHAR(50)," +
                "feelings CHAR(20));";
        db.execSQL(query_create);

        db.execSQL("INSERT INTO upload1 (fname, location, feeling) values ('모래내곱창', '명지대근처', '맛있었다.');");
        db.execSQL("INSERT INTO upload1 (fname, location, feeling) values ('엄마손 떡볶이', '명지대근처', '당면 추가 필수');");
        db.execSQL("INSERT INTO upload1 (dfname, location, feeling) values ('투다리', '명지대근처', '꼬치가 맛있다.');");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if(newVersion == DATABASE_VERSION){
            db.execSQL("DROP TABLE upload1");
            onCreate(db);
        }
    }
}